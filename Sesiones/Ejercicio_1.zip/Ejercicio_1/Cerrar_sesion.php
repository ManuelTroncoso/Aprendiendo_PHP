<?php
session_start();
session_destroy();
header("Location:Pagina1.php")
?>