<?php
session_start();
$name = $_POST['texto'];
$_SESSION["nombre_user"];
echo $_SESSION['nombre_user'];
?>